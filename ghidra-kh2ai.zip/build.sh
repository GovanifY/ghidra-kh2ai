cd data/languages
/home/govanify/Documents/projects/programming/hacking/tools/ghidra/Ghidra/Features/Decompiler/os/linux64/sleigh -c -u -a
cp -rf ../../   /home/govanify/Documents/projects/programming/hacking/tools/ghidra/Ghidra/Processors/kh2a
cd ../../
